if not Leech_Ampule_Effect then
    _G.Leech_Ampule_Effect = {}
	Leech_Ampule_Effect._path = ModPath
	Leech_Ampule_Effect._settings_path = ModPath .. "menu/settings.txt"
	Leech_Ampule_Effect._menu_path = ModPath .. "menu/menu.txt"
	Leech_Ampule_Effect.effect_timer = 0
	Leech_Ampule_Effect.effect_end_timer = 0
	Leech_Ampule_Effect.colors = {
		"ff0000", -- Red
		"FFA500", -- Orange
		"ffff00", -- Yellow
		"00FF00", -- Green
		"00ff80", -- Lime
		"0000ff", -- Blue
		"00ffff", -- Cyan
		"7F00FF", -- Purple,
		"FFC0CB", -- Pink
		"964B00", -- Brown
		"808080", -- Grey
		"ffffff", -- White
		"000000" -- Black
	}
	Leech_Ampule_Effect._settings = {
		mod_enabled = true,
		fade_effect_enabled = true,
		effect_color = 13,
		cooldown_effect_enabled = true,
		cooldown_effect_color = 5,
		end_sfx = true
	}
end

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_LeechAmpuleEffect", function(loc)
	loc:load_localization_file(Leech_Ampule_Effect._path .. "loc/en.json")
end)

Hooks:Add("MenuManagerInitialize", "MenuManagerInitialize_LeechAmpuleEffect", function(menu_manager, nodes)
	function MenuCallbackHandler.LeechAmpuleEffect_toggle_callback(this, item)
		Leech_Ampule_Effect._settings[item:name()] = item:value() == 'on'
		log(tostring(item:name()) .. " | " .. item:value())
	end

	function MenuCallbackHandler.LeechAmpuleEffect_multiple_choice_callback(this, item)
		Leech_Ampule_Effect._settings[item:name()] = item:value()
		log(tostring(item:name()) .. " | " .. item:value())
	end

	function MenuCallbackHandler.LeechAmpuleEffect_reset_options_button()
		Leech_Ampule_Effect:reset_options()
	end

	MenuCallbackHandler.LeechAmpuleEffect_callback_options_closed = function(self)
		Leech_Ampule_Effect:save()
	end

	function Leech_Ampule_Effect:load()
		local file = io.open(Leech_Ampule_Effect._settings_path, 'r')
		if file then
			for k, v in pairs(json.decode(file:read('*all'))) do
				Leech_Ampule_Effect._settings[k] = v
			end
			file:close()
		else
			Leech_Ampule_Effect:save()
		end
	end

	function Leech_Ampule_Effect:save()
		local file = io.open(Leech_Ampule_Effect._settings_path, 'w+')
		if file then
			file:write(json.encode(Leech_Ampule_Effect._settings))
			file:close()
		end
	end

	function  Leech_Ampule_Effect:reset_options()
		local file = io.open(Leech_Ampule_Effect._settings_path, 'r')
		if file then
			file:close()
			os.remove(Leech_Ampule_Effect._settings_path)
		end
		log("RESETTED OPTIONS FILE!")
	end

	Leech_Ampule_Effect:load()

	MenuHelper:LoadFromJsonFile(Leech_Ampule_Effect._menu_path, Leech_Ampule_Effect, Leech_Ampule_Effect._settings)
end)

function Leech_Ampule_Effect:IsEnabled()
	return Leech_Ampule_Effect._settings.mod_enabled
end

function Leech_Ampule_Effect:IsFadeEnabled()
	return Leech_Ampule_Effect._settings.fade_effect_enabled
end

function Leech_Ampule_Effect.EffectColor()
	return Leech_Ampule_Effect.colors[Leech_Ampule_Effect._settings.effect_color]
end

function Leech_Ampule_Effect:IsCooldownEnabled()
	return Leech_Ampule_Effect._settings.cooldown_effect_enabled
end

function Leech_Ampule_Effect:CooldownColor()
	return Leech_Ampule_Effect.colors[Leech_Ampule_Effect._settings.cooldown_effect_color]
end

function Leech_Ampule_Effect:IsEndSfxEnabled()
	return Leech_Ampule_Effect._settings.end_sfx
end

function Leech_Ampule_Effect:LoadTextures()
	for _, file in pairs(file.GetFiles(Leech_Ampule_Effect._path.. "assets/guis/textures/")) do
		DB:create_entry(Idstring("texture"), Idstring("assets/guis/textures/".. file:gsub(".texture", "")), Leech_Ampule_Effect._path.. "assets/guis/textures/".. file)
	end
end

if blt.xaudio then
	blt.xaudio.setup()
end

Leech_Ampule_Effect:LoadTextures()