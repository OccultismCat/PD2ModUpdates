if not Leech_Ampule_Effect then
    _G.Leech_Ampule_Effect = {}
	Leech_Ampule_Effect._path = ModPath
	Leech_Ampule_Effect._settings_path = ModPath .. "menu/settings.txt"
	Leech_Ampule_Effect._menu_path = ModPath .. "menu/menu.txt"
	Leech_Ampule_Effect.effect_timer = 0
	Leech_Ampule_Effect.effect_end_timer = 0
	Leech_Ampule_Effect.colors = {
		"ff0000", -- Red
		"FFA500", -- Orange
		"ff5500", -- Dark Orange
		"ffff00", -- Yellow
		"00FF00", -- Green
		"008000", -- Dark Green
		"00ff80", -- Lime
		"0000ff", -- Blue
		"00aaff", -- Light Blue
		"00ffff", -- Cyan
		"7F00FF", -- Purple
		"FFC0CB", -- Pink
		"FF3357", -- Hot Pink
		"964B00", -- Brown
		"808080", -- Grey
		"ffffff", -- White
		"000000" -- Black
	}
	Leech_Ampule_Effect.sounds = {
		Leech_Ampule_Effect._path .. "assets/sounds/ampule_end_sfx.ogg",
		Leech_Ampule_Effect._path .. "assets/sounds/ampule_end_sfx_2.ogg",
		Leech_Ampule_Effect._path .. "assets/sounds/ampule_end_sfx_3.ogg",
		Leech_Ampule_Effect._path .. "assets/sounds/ampule_end_sfx_custom.ogg"
	}
	Leech_Ampule_Effect.fade_colors = {
		-- Red
		[1] = {
			"1a0000",
			"330000",
			"4d0000",
			"660000",
			"800000",
			"990000",
			"b30000",
			"cc0000",
			"e60000",
			"ff0000"
		},
		-- Orange
		[2] = {
			"1a1100",
			"332100",
			"4d3200",
			"664200",
			"805300",
			"996300",
			"b37400",
			"cc8500",
			"e69500",
			"ffa600"
		},
		-- Dark Orange
		[3] = {
			"1a0800",
			"330f00",
			"4d1700",
			"661f00",
			"802600",
			"992e00",
			"b33600",
			"cc3d00",
			"e64500",
			"ff5500"
		},
		-- Yellow
		[4] = {
			"1a1a00",
			"333300",
			"4d4d00",
			"666600",
			"808000",
			"999900",
			"b3b300",
			"cccc00",
			"e6e600",
			"ffff00"
		},
		-- Green
		[5] = {
			"001a00",
			"003300",
			"004d00",
			"006600",
			"008000",
			"009900",
			"00b300",
			"00cc00",
			"00e600",
			"00ff00"
		},
		-- Dark Green
		[6] = {
			"000d00",
			"001a00",
			"002600",
			"003300",
			"004000",
			"004d00",
			"005900",
			"006600",
			"007300",
			"008000"
		},
		-- Lime
		[7] = {
			"001a0d",
			"00331a",
			"004d28",
			"006635",
			"008042",
			"00994f",
			"00b35c",
			"00cc69",
			"00e677",
			"00ff80"
		},
		-- Blue
		[8] = {
			"00001a",
			"000033",
			"00004d",
			"000066",
			"000080",
			"000099",
			"0000b3",
			"0000cc",
			"0000e6",
			"0000ff"
		},
		-- Light Blue
		[9] = {
			"00111a",
			"002133",
			"00324d",
			"004266",
			"005380",
			"006399",
			"0074b3",
			"0085cc",
			"0095e6",
			"00aaff"
		},
		-- Cyan
		[10] = {
			"001a1a",
			"003333",
			"004d4d",
			"006666",
			"008080",
			"009999",
			"00b3b3",
			"00cccc",
			"00e6e6",
			"00ffff"
		},
		-- Purple
		[11] = {
			"0d001a",
			"1a0033",
			"28004d",
			"350066",
			"420080",
			"4f0099",
			"5c00b3",
			"6900cc",
			"7700e6",
			"8400ff"
		},
		-- Pink
		[12] = {
			"1a1314",
			"332527",
			"4d383b",
			"664a4f",
			"805d63",
			"997077",
			"b3828a",
			"cc959e",
			"e6a8b2",
			"ffbac4"
		},
		-- Hot Pink
		[13] = {
			"1a0509",
			"330a11",
			"4d0f1a",
			"661323",
			"80182d",
			"991d36",
			"b3223f",
			"cc2748",
			"e62c51",
			"FF3357"
		},
		-- Brown
		[14] = {
			"0d0600",
			"1a0c00",
			"261200",
			"331800",
			"401e00",
			"4d2400",
			"592a00",
			"592a00",
			"7d3a00",
			"964B00"
		},
		-- Grey
		[15] = {
			"0d0d0d",
			"1a1a1a",
			"262626",
			"333333",
			"404040",
			"4d4d4d",
			"595959",
			"666666",
			"737373",
			"808080"
		},
		-- White
		[16] = {
			"1a1a1a",
			"333333",
			"4d4d4d",
			"666666",
			"808080",
			"999999",
			"b3b3b3",
			"cccccc",
			"e6e6e6",
			"ffffff"
		},
		-- Black
		[17] = {
			"000000",
			"000000",
			"000000",
			"000000",
			"000000",
			"000000",
			"000000",
			"000000",
			"000000",
			"000000"
		},
	}
	Leech_Ampule_Effect._settings = {
		mod_enabled = true,
		effect_enabled = true,
		effect_color = 1,
		fade_effect_enabled = true,
		fade_effect_type = 1,
		cooldown_effect_enabled = true,
		cooldown_effect_fade_enabled = true,
		cooldown_effect_fade_type = 2,
		cooldown_effect_color = 8,
		end_sfx = true,
		end_sfx_sound = 2
	}
end

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_LeechAmpuleEffect", function(loc)
	loc:load_localization_file(Leech_Ampule_Effect._path .. "loc/en.json")
end)

Hooks:Add("MenuManagerInitialize", "MenuManagerInitialize_LeechAmpuleEffect", function(menu_manager, nodes)

	function MenuCallbackHandler.LeechAmpuleEffect_toggle_callback(this, item)
		Leech_Ampule_Effect._settings[item:name()] = item:value() == 'on'
		log(tostring(item:name()) .. " | " .. item:value())
	end

	function MenuCallbackHandler.LeechAmpuleEffect_multiple_choice_callback(this, item)
		Leech_Ampule_Effect._settings[item:name()] = item:value()
		if item:name() == "end_sfx_sound" then
			local EndSfxSound = XAudio.Source:new(XAudio.Buffer:new(Leech_Ampule_Effect:EndSfxSound()))
			EndSfxSound:set_auto_pause(false)
		end
		log(tostring(item:name()) .. " | " .. item:value())
	end

	function MenuCallbackHandler.LeechAmpuleEffect_reset_options_button()
		Leech_Ampule_Effect:reset_options()
	end

	MenuCallbackHandler.LeechAmpuleEffect_callback_options_closed = function(self)
		Leech_Ampule_Effect:save()
	end

	function Leech_Ampule_Effect:load()
		local file = io.open(Leech_Ampule_Effect._settings_path, 'r')
		if file then
			for k, v in pairs(json.decode(file:read('*all'))) do
				Leech_Ampule_Effect._settings[k] = v
			end
			file:close()
		else
			Leech_Ampule_Effect:save()
		end
	end

	function Leech_Ampule_Effect:save()
		local file = io.open(Leech_Ampule_Effect._settings_path, 'w+')
		if file then
			file:write(json.encode(Leech_Ampule_Effect._settings))
			file:close()
		end
	end

	function  Leech_Ampule_Effect:reset_options()
		local file = io.open(Leech_Ampule_Effect._settings_path, 'r')
		if file then
			file:close()
			os.remove(Leech_Ampule_Effect._settings_path)
		end
		log("RESETTED OPTIONS FILE!")
	end

	Leech_Ampule_Effect:load()

	MenuHelper:LoadFromJsonFile(Leech_Ampule_Effect._menu_path, Leech_Ampule_Effect, Leech_Ampule_Effect._settings)
end)

function Leech_Ampule_Effect:IsEnabled()
	return Leech_Ampule_Effect._settings.mod_enabled
end

function Leech_Ampule_Effect:IsEffectEnabled()
	return Leech_Ampule_Effect._settings.effect_enabled
end

function Leech_Ampule_Effect:IsFadeEnabled()
	return Leech_Ampule_Effect._settings.fade_effect_enabled
end

function Leech_Ampule_Effect:FadeType()
	return Leech_Ampule_Effect._settings.fade_effect_type
end

function Leech_Ampule_Effect:EffectColor()
	return Leech_Ampule_Effect.fade_colors[Leech_Ampule_Effect._settings.effect_color]
end

function Leech_Ampule_Effect:IsCooldownEnabled()
	return Leech_Ampule_Effect._settings.cooldown_effect_enabled
end

function Leech_Ampule_Effect:IsCooldownFadeEnabled()
	return Leech_Ampule_Effect._settings.cooldown_effect_fade_enabled
end

function Leech_Ampule_Effect:CooldownFadeType()
	return Leech_Ampule_Effect._settings.cooldown_effect_fade_type
end

function Leech_Ampule_Effect:CooldownColor()
	return Leech_Ampule_Effect.fade_colors[Leech_Ampule_Effect._settings.cooldown_effect_color]
end

function Leech_Ampule_Effect:IsEndSfxEnabled()
	return Leech_Ampule_Effect._settings.end_sfx
end

function Leech_Ampule_Effect:EndSfxSound()
	return Leech_Ampule_Effect.sounds[Leech_Ampule_Effect._settings.end_sfx_sound]
end

function Leech_Ampule_Effect:LoadTextures()
	for _, file in pairs(file.GetFiles(Leech_Ampule_Effect._path.. "assets/guis/textures/")) do
		DB:create_entry(Idstring("texture"), Idstring("assets/guis/textures/".. file:gsub(".texture", "")), Leech_Ampule_Effect._path.. "assets/guis/textures/".. file)
	end
end

if blt.xaudio then
	blt.xaudio.setup()
end

Leech_Ampule_Effect:LoadTextures()

