local function Leech_Effect_Fade(time, hud_panel)
	if time <= 5 and time >= 4.5 then
		hud_panel:set_color(Color("100000"))
	elseif time <= 4.5 and time >= 3.5 then
		hud_panel:set_color(Color("200000"))
	elseif time <= 3.5 and time >= 3 then
		hud_panel:set_color(Color("300000"))
	elseif time <= 3 and time >= 2.5 then
		hud_panel:set_color(Color("400000"))
	elseif time <= 2.5 and time >= 2 then
		hud_panel:set_color(Color("500000"))
	elseif time <= 2 and time >= 1.5 then
		hud_panel:set_color(Color("600000"))
	elseif time <= 1.5 and time >= 1 then
		hud_panel:set_color(Color("700000"))
	elseif time <= 1 and time >= 0.5 then
		hud_panel:set_color(Color("800000"))
	elseif time <= 0.5 and time >= 0.01 then
		hud_panel:set_color(Color("900000"))
	end
end

local function Leech_Effect_update(t, dt)
	if not Leech_Ampule_Effect:IsEnabled() then
		return
	end

	local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	local Leech_Ampule_Effect_hud_panel = hud.panel:child("Leech_Ampule_Effect_hud_panel")

	if not Leech_Ampule_Effect_hud_panel then
		return
	end

	if Leech_Ampule_Effect.effect_timer > 0 then
		Leech_Ampule_Effect.effect_timer = Leech_Ampule_Effect.effect_timer - TimerManager:main():delta_time()
		Leech_Ampule_Effect_hud_panel:set_visible(true)
		local hudinfo = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2)
		Leech_Ampule_Effect_hud_panel:animate(hudinfo.flash_icon, 4000000000)
		if Leech_Ampule_Effect:IsFadeEnabled() then
			Leech_Effect_Fade(Leech_Ampule_Effect.effect_timer, Leech_Ampule_Effect_hud_panel)
		else
			Leech_Ampule_Effect_hud_panel:set_color(Color(Leech_Ampule_Effect.EffectColor()))
		end
	elseif Leech_Ampule_Effect.effect_timer <= 0 then
		Leech_Ampule_Effect_hud_panel:stop()
		Leech_Ampule_Effect_hud_panel:set_visible(false)
		if Leech_Ampule_Effect.IsFadeEnabled() then
			Leech_Ampule_Effect_hud_panel:set_color(Color("000000"))
		else
			Leech_Ampule_Effect_hud_panel:set_color(Color(Leech_Ampule_Effect.EffectColor()))
		end
	end
end

local function Leech_Effect_End_update(t, dt)
	if not Leech_Ampule_Effect:IsEnabled() then
		return
	elseif not Leech_Ampule_Effect.IsCooldownEnabled() then
		return
	end

	local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	local Leech_Ampule_Effect_End_Cooldown_hud_panel = hud.panel:child("Leech_Ampule_Effect_End_Cooldown_hud_panel")

	if not Leech_Ampule_Effect_End_Cooldown_hud_panel then
		return
	end

	if Leech_Ampule_Effect.effect_end_timer > 0 then
		Leech_Ampule_Effect.effect_end_timer = Leech_Ampule_Effect.effect_end_timer - TimerManager:main():delta_time()
		Leech_Ampule_Effect_End_Cooldown_hud_panel:set_visible(true)
		local hudinfo = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2)
		Leech_Ampule_Effect_End_Cooldown_hud_panel:animate(hudinfo.flash_icon, 4000000000)
		Leech_Ampule_Effect_End_Cooldown_hud_panel:set_color(Color(Leech_Ampule_Effect.CooldownColor()))
	elseif Leech_Ampule_Effect.effect_end_timer <= 0 then
		Leech_Ampule_Effect_End_Cooldown_hud_panel:stop()
		Leech_Ampule_Effect_End_Cooldown_hud_panel:set_visible(false)
	end
end

if string.lower(RequiredScript) == "lib/managers/hudmanager" then
	Hooks:PostHook(HUDManager, "update", "Leech_Effect_HUDManager_update", function(self, t, dt)
		Leech_Effect_update(t, dt)
		Leech_Effect_End_update(t, dt)
	end)
end

Hooks:PreHook(PlayerManager, "activate_temporary_upgrade", "Leech_Effect_PlayerManager_activate_temporary_upgrade", function (self, category, upgrade)
	if upgrade ~= "copr_ability" then
		return
	end
	local upgrade_value = self:upgrade_value(category, upgrade)[2]
	if not upgrade_value then
		return
	end
	Leech_Ampule_Effect.effect_timer = upgrade_value
	local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	if not hud.panel:child("Leech_Ampule_Effect_hud_panel") then
		local Leech_Ampule_Effect_hud_panel = hud.panel:bitmap({
			name = "Leech_Ampule_Effect_hud_panel",
			visible = false,
			texture = "assets/guis/textures/leech_ampule_effect",
			layer = 0,
			color = Color("000000"),
			blend_mode = "disable",
			w = hud.panel:w(),
			h = hud.panel:h(),
			x = 0,
			y = 0 
		})
	end
end)

Hooks:PreHook(PlayerManager, "deactivate_temporary_upgrade", "Leech_Effect_PlayerManager_deactivate_temporary_upgrade", function (self, category, upgrade)
	if upgrade ~= "copr_ability" then
		return
	end

	if Leech_Ampule_Effect:IsEndSfxEnabled() then
		XAudio.Source:new(XAudio.Buffer:new(Leech_Ampule_Effect._path.."assets/sounds/ampule_end_sfx.ogg"))
	end

end)

Hooks:PreHook(PlayerManager, "_on_grenade_cooldown_end", "_on_grenade_cooldown_end_custom", function (self)
	local tweak = tweak_data.blackmarket.projectiles[managers.blackmarket:equipped_grenade()]
	if tweak and tweak.name_id == "bm_grenade_copr_ability" then
		Leech_Ampule_Effect.effect_end_timer = 0.70
		local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
		if not hud.panel:child("Leech_Ampule_Effect_End_Cooldown_hud_panel") then
			local Leech_Ampule_Effect_End_Cooldown_hud_panel = hud.panel:bitmap({
				name = "Leech_Ampule_Effect_End_Cooldown_hud_panel",
				visible = false,
				texture = "assets/guis/textures/leech_end_cooldown_effect",
				layer = 0,
				color = Color(Leech_Ampule_Effect.CooldownColor()),
				blend_mode = "disable",
				w = hud.panel:w(),
				h = hud.panel:h(),
				x = 0,
				y = 0 
			})
		end
	end
end)

