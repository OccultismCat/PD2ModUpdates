local function Leech_Effect_Fade_In(time, hud_panel)
	local fade_effect_color = Leech_Ampule_Effect:EffectColor()

	if time >= 5.1 then
		hud_panel:set_color(Color("000000"))
	end

	if time <= 5 and time >= 4.5 then
		hud_panel:set_color(Color(fade_effect_color[1]))
	elseif time <= 4.5 and time >= 3.5 then
		hud_panel:set_color(Color(fade_effect_color[2]))
	elseif time <= 3.5 and time >= 3 then
		hud_panel:set_color(Color(fade_effect_color[3]))
	elseif time <= 3 and time >= 2.5 then
		hud_panel:set_color(Color(fade_effect_color[4]))
	elseif time <= 2.5 and time >= 2 then
		hud_panel:set_color(Color(fade_effect_color[5]))
	elseif time <= 2 and time >= 1.5 then
		hud_panel:set_color(Color(fade_effect_color[6]))
	elseif time <= 1.5 and time >= 1 then
		hud_panel:set_color(Color(fade_effect_color[7]))
	elseif time <= 1 and time >= 0.5 then
		hud_panel:set_color(Color(fade_effect_color[8]))
	elseif time <= 0.5 and time >= 0.01 then
		hud_panel:set_color(Color(fade_effect_color[9]))
	end
end

local function Leech_Effect_Cooldown_Fade_In(time, hud_panel)
	local fade_effect_color = Leech_Ampule_Effect:CooldownColor()

	if time >= 0.51 then
		hud_panel:set_color(Color("000000"))
	end

	if time <= 0.50 and time >= 0.45 then
		hud_panel:set_color(Color(fade_effect_color[1]))
	elseif time <= 0.45 and time >= 0.40 then
		hud_panel:set_color(Color(fade_effect_color[2]))
	elseif time <= 0.40 and time >= 0.35 then
		hud_panel:set_color(Color(fade_effect_color[3]))
	elseif time <= 0.35 and time >= 0.30 then
		hud_panel:set_color(Color(fade_effect_color[4]))
	elseif time <= 0.30 and time >= 0.25 then
		hud_panel:set_color(Color(fade_effect_color[5]))
	elseif time <= 0.25 and time >= 0.20 then
		hud_panel:set_color(Color(fade_effect_color[6]))
	elseif time <= 0.20 and time >= 0.15 then
		hud_panel:set_color(Color(fade_effect_color[7]))
	elseif time <= 0.15 and time >= 0.10 then
		hud_panel:set_color(Color(fade_effect_color[8]))
	elseif time <= 0.10 and time >= 0.01 then
		hud_panel:set_color(Color(fade_effect_color[9]))
	end
end

local function Leech_Effect_Fade_Out(time, hud_panel)
	local fade_effect_color = Leech_Ampule_Effect:EffectColor()

	if time >= 5.1 then
		hud_panel:set_color(Color(fade_effect_color[10]))
	end

	if time <= 5 and time >= 4.5 then
		hud_panel:set_color(Color(fade_effect_color[9]))
	elseif time <= 4.5 and time >= 3.5 then
		hud_panel:set_color(Color(fade_effect_color[8]))
	elseif time <= 3.5 and time >= 3 then
		hud_panel:set_color(Color(fade_effect_color[7]))
	elseif time <= 3 and time >= 2.5 then
		hud_panel:set_color(Color(fade_effect_color[6]))
	elseif time <= 2.5 and time >= 2 then
		hud_panel:set_color(Color(fade_effect_color[5]))
	elseif time <= 2 and time >= 1.5 then
		hud_panel:set_color(Color(fade_effect_color[4]))
	elseif time <= 1.5 and time >= 1 then
		hud_panel:set_color(Color(fade_effect_color[3]))
	elseif time <= 1 and time >= 0.5 then
		hud_panel:set_color(Color(fade_effect_color[2]))
	elseif time <= 0.5 and time >= 0.01 then
		hud_panel:set_color(Color(fade_effect_color[1]))
	end
end

local function Leech_Effect_Cooldown_Fade_Out(time, hud_panel)
	local fade_effect_color = Leech_Ampule_Effect:CooldownColor()

	if time >= 0.51 then
		hud_panel:set_color(Color(fade_effect_color[10]))
	end

	if time <= 0.50 and time >= 0.45 then
		hud_panel:set_color(Color(fade_effect_color[9]))
	elseif time <= 0.45 and time >= 0.40 then
		hud_panel:set_color(Color(fade_effect_color[8]))
	elseif time <= 0.40 and time >= 0.35 then
		hud_panel:set_color(Color(fade_effect_color[7]))
	elseif time <= 0.35 and time >= 0.30 then
		hud_panel:set_color(Color(fade_effect_color[6]))
	elseif time <= 0.30 and time >= 0.25 then
		hud_panel:set_color(Color(fade_effect_color[5]))
	elseif time <= 0.25 and time >= 0.20 then
		hud_panel:set_color(Color(fade_effect_color[4]))
	elseif time <= 0.20 and time >= 0.15 then
		hud_panel:set_color(Color(fade_effect_color[3]))
	elseif time <= 0.15 and time >= 0.10 then
		hud_panel:set_color(Color(fade_effect_color[2]))
	elseif time <= 0.10 and time >= 0.01 then
		hud_panel:set_color(Color(fade_effect_color[1]))
	end
end

local function Leech_Effect_update(t, dt)
	if not Leech_Ampule_Effect:IsEnabled() or not Leech_Ampule_Effect:IsEffectEnabled() then
		return
	end

	local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	local Leech_Ampule_Effect_hud_panel = hud.panel:child("Leech_Ampule_Effect_hud_panel")

	if not Leech_Ampule_Effect_hud_panel then
		return
	end

	if Leech_Ampule_Effect.effect_timer > 0 then
		Leech_Ampule_Effect.effect_timer = Leech_Ampule_Effect.effect_timer - TimerManager:main():delta_time()
		Leech_Ampule_Effect_hud_panel:set_visible(true)
		local hudinfo = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2)
		Leech_Ampule_Effect_hud_panel:animate(hudinfo.flash_icon, 4000000000)
		if Leech_Ampule_Effect:IsFadeEnabled() then
			if Leech_Ampule_Effect:FadeType() == 1 then
				Leech_Effect_Fade_In(Leech_Ampule_Effect.effect_timer, Leech_Ampule_Effect_hud_panel)
			else
				Leech_Effect_Fade_Out(Leech_Ampule_Effect.effect_timer, Leech_Ampule_Effect_hud_panel)
			end
		else
			Leech_Ampule_Effect_hud_panel:set_color(Color(Leech_Ampule_Effect:EffectColor()[10]))
		end
	elseif Leech_Ampule_Effect.effect_timer <= 0 then
		Leech_Ampule_Effect_hud_panel:stop()
		Leech_Ampule_Effect_hud_panel:set_visible(false)
	end
end

local function Leech_Effect_End_update(t, dt)
	if not Leech_Ampule_Effect:IsEnabled() or not Leech_Ampule_Effect:IsCooldownEnabled() then
		return
	end

	local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	local Leech_Ampule_Effect_End_Cooldown_hud_panel = hud.panel:child("Leech_Ampule_Effect_End_Cooldown_hud_panel")

	if not Leech_Ampule_Effect_End_Cooldown_hud_panel then
		return
	end

	if Leech_Ampule_Effect.effect_end_timer > 0 then
		Leech_Ampule_Effect.effect_end_timer = Leech_Ampule_Effect.effect_end_timer - TimerManager:main():delta_time()
		Leech_Ampule_Effect_End_Cooldown_hud_panel:set_visible(true)
		local hudinfo = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2)
		Leech_Ampule_Effect_End_Cooldown_hud_panel:animate(hudinfo.flash_icon, 4000000000)
		if Leech_Ampule_Effect:IsCooldownFadeEnabled() then
			if Leech_Ampule_Effect:FadeType() == 1 then
				Leech_Effect_Cooldown_Fade_In(Leech_Ampule_Effect.effect_end_timer, Leech_Ampule_Effect_End_Cooldown_hud_panel)
			else
				Leech_Effect_Cooldown_Fade_Out(Leech_Ampule_Effect.effect_end_timer, Leech_Ampule_Effect_End_Cooldown_hud_panel)
			end
		else
			Leech_Ampule_Effect_End_Cooldown_hud_panel:set_color(Color(Leech_Ampule_Effect:CooldownColor()[10]))
		end
	elseif Leech_Ampule_Effect.effect_end_timer <= 0 then
		Leech_Ampule_Effect_End_Cooldown_hud_panel:stop()
		Leech_Ampule_Effect_End_Cooldown_hud_panel:set_visible(false)
	end
end

if string.lower(RequiredScript) == "lib/managers/hudmanager" then
	Hooks:PostHook(HUDManager, "update", "Leech_Effect_HUDManager_update", function(self, t, dt)
		Leech_Effect_update(t, dt)
		Leech_Effect_End_update(t, dt)
	end)
end

Hooks:PostHook(PlayerManager, "activate_temporary_upgrade", "Leech_Effect_PlayerManager_activate_temporary_upgrade", function (self, category, upgrade)
	if upgrade ~= "copr_ability" then
		return
	end

	local upgrade_value = self:upgrade_value(category, upgrade)[2]
	
	if not upgrade_value then
		return
	end
	
	Leech_Ampule_Effect.effect_timer = upgrade_value
	local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	if not hud.panel:child("Leech_Ampule_Effect_hud_panel") then
		local Leech_Ampule_Effect_hud_panel = hud.panel:bitmap({
			name = "Leech_Ampule_Effect_hud_panel",
			visible = false,
			texture = "assets/guis/textures/leech_ampule_effect",
			layer = 0,
			color = Color("000000"),
			blend_mode = "disable",
			w = hud.panel:w(),
			h = hud.panel:h(),
			x = 0,
			y = 0 
		})
	end
end)

Hooks:PostHook(PlayerManager, "deactivate_temporary_upgrade", "Leech_Effect_PlayerManager_deactivate_temporary_upgrade", function (self, category, upgrade)
	if not Leech_Ampule_Effect:IsEnabled() then
		return
	end

	if upgrade ~= "copr_ability" then
		return
	end

	if Leech_Ampule_Effect:IsEndSfxEnabled() then
		local EndSfxSound = XAudio.Source:new(XAudio.Buffer:new(Leech_Ampule_Effect:EndSfxSound()))
	end

end)

Hooks:PostHook(PlayerManager, "_on_grenade_cooldown_end", "_on_grenade_cooldown_end_custom", function (self)
	if not Leech_Ampule_Effect:IsEnabled() then
		return
	end
	
	local tweak = tweak_data.blackmarket.projectiles[managers.blackmarket:equipped_grenade()]
	if tweak and tweak.name_id == "bm_grenade_copr_ability" then
		Leech_Ampule_Effect.effect_end_timer = 0.70
		local hud = managers.hud:script( PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
		if not hud.panel:child("Leech_Ampule_Effect_End_Cooldown_hud_panel") then
			local Leech_Ampule_Effect_End_Cooldown_hud_panel = hud.panel:bitmap({
				name = "Leech_Ampule_Effect_End_Cooldown_hud_panel",
				visible = false,
				texture = "assets/guis/textures/leech_end_cooldown_effect",
				layer = 0,
				color = Color(Leech_Ampule_Effect:CooldownColor()),
				blend_mode = "disable",
				w = hud.panel:w(),
				h = hud.panel:h(),
				x = 0,
				y = 0 
			})
		end
	end
end)

